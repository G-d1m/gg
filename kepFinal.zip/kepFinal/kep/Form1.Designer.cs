﻿namespace kep
{
    partial class KEP
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            name = new TextBox();
            email = new TextBox();
            button1 = new Button();
            address = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            dmy = new DateTimePicker();
            phone = new TextBox();
            label5 = new Label();
            type = new ComboBox();
            button5 = new Button();
            idd = new TextBox();
            id = new Label();
            dataGridView1 = new DataGridView();
            ext = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // name
            // 
            name.BackColor = Color.FromArgb(64, 64, 60);
            name.ForeColor = Color.WhiteSmoke;
            name.Location = new Point(98, 90);
            name.Name = "name";
            name.Size = new Size(191, 27);
            name.TabIndex = 0;
            // 
            // email
            // 
            email.BackColor = Color.FromArgb(64, 64, 60);
            email.ForeColor = Color.WhiteSmoke;
            email.Location = new Point(98, 132);
            email.Name = "email";
            email.Size = new Size(284, 27);
            email.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.LightGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.WhiteSmoke;
            button1.Location = new Point(98, 364);
            button1.Margin = new Padding(57, 53, 57, 53);
            button1.Name = "button1";
            button1.Size = new Size(86, 25);
            button1.TabIndex = 2;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // address
            // 
            address.BackColor = Color.FromArgb(64, 64, 60);
            address.ForeColor = Color.WhiteSmoke;
            address.Location = new Point(98, 179);
            address.Name = "address";
            address.Size = new Size(284, 27);
            address.TabIndex = 3;
            // 
            // button2
            // 
            button2.BackColor = Color.IndianRed;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            button2.ForeColor = Color.WhiteSmoke;
            button2.Location = new Point(198, 364);
            button2.Name = "button2";
            button2.Size = new Size(86, 25);
            button2.TabIndex = 6;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.SandyBrown;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            button3.ForeColor = Color.WhiteSmoke;
            button3.Location = new Point(297, 364);
            button3.Name = "button3";
            button3.Size = new Size(86, 25);
            button3.TabIndex = 7;
            button3.Text = "Modify";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Thistle;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            button4.ForeColor = Color.WhiteSmoke;
            button4.Location = new Point(297, 537);
            button4.Name = "button4";
            button4.Size = new Size(86, 25);
            button4.TabIndex = 8;
            button4.Text = "Show All";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.KEPmLINE_Logo_slogan;
            pictureBox1.ImageLocation = "";
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(258, 83);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(14, 98);
            label1.Name = "label1";
            label1.Size = new Size(48, 16);
            label1.TabIndex = 13;
            label1.Text = "Name ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.WhiteSmoke;
            label2.Location = new Point(14, 135);
            label2.Name = "label2";
            label2.Size = new Size(52, 16);
            label2.TabIndex = 14;
            label2.Text = "E-mail ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.WhiteSmoke;
            label3.Location = new Point(14, 182);
            label3.Name = "label3";
            label3.Size = new Size(59, 16);
            label3.TabIndex = 14;
            label3.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.WhiteSmoke;
            label4.Location = new Point(14, 238);
            label4.Name = "label4";
            label4.Size = new Size(38, 16);
            label4.TabIndex = 14;
            label4.Text = "Birth";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.WhiteSmoke;
            label6.Location = new Point(14, 329);
            label6.Name = "label6";
            label6.Size = new Size(38, 16);
            label6.TabIndex = 14;
            label6.Text = "Type";
            // 
            // dmy
            // 
            dmy.CalendarForeColor = Color.WhiteSmoke;
            dmy.CalendarMonthBackground = Color.FromArgb(64, 64, 60);
            dmy.CalendarTitleBackColor = Color.FromArgb(64, 64, 60);
            dmy.CalendarTitleForeColor = Color.WhiteSmoke;
            dmy.CalendarTrailingForeColor = Color.WhiteSmoke;
            dmy.Location = new Point(98, 231);
            dmy.MaxDate = new DateTime(2020, 12, 31, 0, 0, 0, 0);
            dmy.Name = "dmy";
            dmy.Size = new Size(284, 27);
            dmy.TabIndex = 15;
            dmy.Value = new DateTime(2020, 12, 31, 0, 0, 0, 0);
            // 
            // phone
            // 
            phone.BackColor = Color.FromArgb(64, 64, 60);
            phone.ForeColor = Color.WhiteSmoke;
            phone.Location = new Point(98, 276);
            phone.Name = "phone";
            phone.Size = new Size(284, 27);
            phone.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.WhiteSmoke;
            label5.Location = new Point(14, 285);
            label5.Name = "label5";
            label5.Size = new Size(48, 16);
            label5.TabIndex = 14;
            label5.Text = "Phone";
            // 
            // type
            // 
            type.BackColor = Color.FromArgb(64, 64, 60);
            type.FlatStyle = FlatStyle.Flat;
            type.ForeColor = Color.WhiteSmoke;
            type.FormattingEnabled = true;
            type.Items.AddRange(new object[] { "birth certificate", "confirmation", "original signature" });
            type.Location = new Point(98, 325);
            type.MaxDropDownItems = 3;
            type.Name = "type";
            type.Size = new Size(284, 24);
            type.TabIndex = 16;
            type.Text = "birth certificate";
            // 
            // button5
            // 
            button5.BackColor = Color.SteelBlue;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            button5.ForeColor = Color.WhiteSmoke;
            button5.Location = new Point(297, 94);
            button5.Name = "button5";
            button5.Size = new Size(86, 25);
            button5.TabIndex = 18;
            button5.Text = "Search";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // idd
            // 
            idd.BackColor = Color.FromArgb(64, 64, 60);
            idd.ForeColor = Color.WhiteSmoke;
            idd.Location = new Point(329, 54);
            idd.Name = "idd";
            idd.Size = new Size(53, 27);
            idd.TabIndex = 21;
            idd.TextAlign = HorizontalAlignment.Center;
            // 
            // id
            // 
            id.AutoSize = true;
            id.ForeColor = Color.WhiteSmoke;
            id.Location = new Point(270, 58);
            id.Name = "id";
            id.Size = new Size(22, 16);
            id.TabIndex = 22;
            id.Text = "ID";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(64, 64, 60);
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.FromArgb(64, 64, 60);
            dataGridView1.Location = new Point(16, 402);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(274, 159);
            dataGridView1.TabIndex = 20;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // ext
            // 
            ext.BackColor = Color.PaleVioletRed;
            ext.FlatAppearance.BorderSize = 0;
            ext.FlatStyle = FlatStyle.Flat;
            ext.Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            ext.ForeColor = Color.WhiteSmoke;
            ext.Location = new Point(297, 506);
            ext.Name = "ext";
            ext.Size = new Size(86, 25);
            ext.TabIndex = 23;
            ext.Text = "extract";
            ext.UseVisualStyleBackColor = false;
            ext.Click += ext_Click;
            // 
            // KEP
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 60);
            ClientSize = new Size(421, 574);
            Controls.Add(ext);
            Controls.Add(id);
            Controls.Add(idd);
            Controls.Add(dataGridView1);
            Controls.Add(button5);
            Controls.Add(type);
            Controls.Add(dmy);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(phone);
            Controls.Add(address);
            Controls.Add(button1);
            Controls.Add(email);
            Controls.Add(name);
            Font = new Font("Yu Gothic Medium", 9F, FontStyle.Bold);
            ForeColor = Color.FromArgb(64, 64, 60);
            Name = "KEP";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "KEP";
            Load += KEP_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox name;
        private TextBox email;
        private Button button1;
        private TextBox address;
        private Button button2;
        private Button button3;
        private Button button4;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private DateTimePicker dmy;
        private TextBox phone;
        private Label label5;
        private ComboBox type;
        private Button button5;
        private TextBox idd;
        private Label id;
        private DataGridView dataGridView1;
        private Button ext;
    }
}
