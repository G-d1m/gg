using System.Data;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.IO;
using System.Drawing;
using Microsoft.VisualBasic.ApplicationServices;


namespace kep
{
    public partial class KEP : Form
    {
        private readonly Clean clear = new Clean();


        SqlConnection connection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\georg\Documents\DB_S1.mdf;Integrated Security = True; Connect Timeout = 30");
        string a, b;
        public KEP()
        {
            InitializeComponent();
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);
            button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);
            button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);
            button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);
            ext.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 60);

        }
        private void KEP_Load(object sender, EventArgs e)
        {



        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = DateTime.Now.ToString("MM/dd/yyyy h:mm tt");
            if (name.Text == null || name.Text == "" || idd.Text == null || idd.Text == "" || email.Text == null || email.Text == "" || address.Text == null || address.Text == "" || phone.Text == null || phone.Text == "" || type.Text == null || type.Text == "")
            {
                MessageBox.Show("please fill all the boxes");
                return;
            }
            else
            {
                if (phone.TextLength == 10)
                {
                    if (!idd.Text.Contains("0"))
                    {
                        if (email.Text.Contains("@"))
                        {

                            connection.Open();
                            SqlCommand cmd = connection.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "insert into [MYtable] ( id, Name, E_mail, Address, DateOfB, Phone, Type, Date) values ('" + idd.Text + "','" + name.Text + "',' " + email.Text + "',' " + address.Text + "',' " + dmy.Text + "',' " + phone.Text + "',' " + type.Text + "', '" + a + "')";
                            cmd.ExecuteNonQuery();
                            connection.Close();
                            clear.ClearF(idd, name, email, address, phone);
                            disp();
                        }
                        else
                        {

                            MessageBox.Show("please fill a valid email");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("ID must be > 0");
                        return;

                    }
                }
                else
                {
                    MessageBox.Show("enter valid number");
                    return;
                }
            }
        }


        public void disp()
        {
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [MYtable]";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter datt = new SqlDataAdapter(cmd);
            datt.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            disp();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from [MYtable] where id ='" + idd.Text + "'";
            cmd.ExecuteNonQuery();
            connection.Close();
            clear.ClearF(idd, name, email, address, phone);
            disp();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            b = DateTime.Now.ToString("MM/dd/yyyy h:mm tt");
            if (name.Text == null || name.Text == "" || idd.Text == null || idd.Text == "" || email.Text == null || email.Text == "" || address.Text == null || address.Text == "" || phone.Text == null || phone.Text == "" || type.Text == null || type.Text == "")
            {

                MessageBox.Show("please fill all the boxes");
                return;
            }
            else
            {
                if (phone.TextLength == 10)
                {
                    if (!idd.Text.Contains("0"))
                    {
                        if (email.Text.Contains("@"))
                        {
                            connection.Open();
                            SqlCommand cmd = connection.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "update [MYtable] set name ='" + name.Text + "', E_mail ='" + email.Text + "', address='" + address.Text + "',DateOfB='" + dmy.Text + "',Phone='" + phone.Text + "',Type='" + type.Text + "',Date='" + b + "' where id ='" + idd.Text + "'";
                            cmd.ExecuteNonQuery();
                            connection.Close();
                            clear.ClearF(idd, name, email, address, phone);
                            disp();
                        }
                        else
                        {
                            MessageBox.Show("please fill a valid email");
                            return;

                        }
                    }
                    else
                    {
                        MessageBox.Show("ID must be > 0");
                        return;

                    }
                }
                else
                {
                    MessageBox.Show("enter valid number");
                    return;
                }

            }
        }


        private void button5_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = connection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [MYtable]  where name ='" + name.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dtr = new DataTable();
            SqlDataAdapter daa = new SqlDataAdapter(cmd);
            daa.Fill(dtr);
            dataGridView1.DataSource = dtr;
            connection.Close();
            clear.ClearF(idd, name, email, address, phone);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridView1.CurrentRow.Selected = true;
                name.Text = dataGridView1.Rows[e.RowIndex].Cells["name"].FormattedValue.ToString();
                idd.Text = dataGridView1.Rows[e.RowIndex].Cells["id"].FormattedValue.ToString();
                email.Text = dataGridView1.Rows[e.RowIndex].Cells["E_mail"].FormattedValue.ToString();
                address.Text = dataGridView1.Rows[e.RowIndex].Cells["address"].FormattedValue.ToString();
                dmy.Text = dataGridView1.Rows[e.RowIndex].Cells["DateOfB"].FormattedValue.ToString();
                phone.Text = dataGridView1.Rows[e.RowIndex].Cells["Phone"].FormattedValue.ToString();
                type.Text = dataGridView1.Rows[e.RowIndex].Cells["type"].FormattedValue.ToString();

            }

        }
        TWR fileManager = new TWR(@"C:\Users\georg\source\repos\projects\kepFinal\KepF.txt");
        private void ext_Click(object sender, EventArgs e)
        {

            fileManager.SaveData(dataGridView1);
        }



    }

}


