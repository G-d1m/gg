﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;


namespace kep
{
    internal class TWR
    {
  
            private string flPath;

            public TWR(string path)
            {
                flPath = path;
                string folderPath = Path.GetDirectoryName(flPath);

                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath); 
                }
            }

            public void SaveData(DataGridView dataGridView)
            {
                try
                {
                    if (dataGridView.DataSource != null)
                    {
                        int colC = dataGridView.Columns.Count;
                        int rowC = dataGridView.Rows.Count;

                        using (TextWriter t = new StreamWriter(flPath))
                        {
                            for (int i = 0; i < rowC - 1; i++)
                            {
                                for (int j = 0; j < colC; j++)
                                {
                                    var cellValue = dataGridView.Rows[i].Cells[j].Value;
                                    string value = cellValue != null ? cellValue.ToString() : "NULL";
                                    t.Write($" {value} |");
                                }
                                t.WriteLine();
                                t.WriteLine(new string('=', 150));
                            }
                        }
                        MessageBox.Show("Extracted");
                    }
                    else
                    {
                        MessageBox.Show("No data");
                    }
                }
                catch (Exception ex)
                {
                MessageBox.Show(ex.Message);

                }
            }
    }
}

