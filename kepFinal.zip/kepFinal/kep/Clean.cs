﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Windows.Forms;

namespace kep
{
    internal class Clean
    {
        public void ClearF(params TextBox[] textFields)
        {
            foreach (var textField in textFields)
            {
                textField.Text = string.Empty;
            }

        }

    }
}
